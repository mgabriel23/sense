import { DEFAULT_DEVICE_CATEGORIES } from "./devices.js";
import { normalizeUrl } from "./url.js";
import { DeviceGrid } from "./device-grid.js";
import {
  getDeviceCatalog,
  getDeviceSelection,
  setDeviceSelection,
  getLastUrl,
  setLastUrl,
  getRecentUrls,
  addRecentUrl,
  getVisibleCategories,
  setVisibleCategories,
  getTourCompleted,
  setTourCompleted,
} from "../shared/storage.js";
import { applyStoredTheme, initThemeToggle } from "../shared/theme.js";
import { showToast } from "../shared/toast.js";
import { CATEGORY_ICONS } from "../shared/device-icons.js";
import { Tour } from "./tour.js";
import { captureAllCards } from "./screenshot.js";

const urlForm = document.getElementById("url-form");
const urlInput = document.getElementById("url-input");
const urlError = document.getElementById("url-error");
const gridEl = document.getElementById("grid");
const emptyStateEl = document.getElementById("empty-state");
const reloadBtn = document.getElementById("reload-all");
const exportAllBtn = document.getElementById("export-all");
const recentUrlsMenu = document.getElementById("recent-urls-menu");
const categoryTogglesEl = document.getElementById("category-toggles");
const themeToggleBtn = document.getElementById("theme-toggle");
const tourHelpBtn = document.getElementById("tour-help");
const openSettingsBtn = document.getElementById("open-settings");

// Each category pill's leading glyph swaps between its own device icon
// (hidden) and this checkmark (shown) — the icon "becomes" the
// confirmation on toggle, rather than sitting next to a separate static
// checkbox box.
const CHECK_ICON =
  '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg>';

const HISTORY_ICON =
  '<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"></circle><polyline points="12 7 12 12 15.5 14"></polyline></svg>';
const GO_ICON =
  '<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg>';

const SUN_ICON =
  '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="5"></circle><line x1="12" y1="1" x2="12" y2="3"></line><line x1="12" y1="21" x2="12" y2="23"></line><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"></line><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"></line><line x1="1" y1="12" x2="3" y2="12"></line><line x1="21" y1="12" x2="23" y2="12"></line><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"></line><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"></line></svg>';
const MOON_ICON =
  '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"></path></svg>';

// Matches the static markup in viewer.html — cached so it can be restored
// after temporarily swapping in SPINNER_ICON during a combined export.
const EXPORT_ICON = exportAllBtn.innerHTML;
const SPINNER_ICON =
  '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M12 2a10 10 0 0 1 10 10"></path></svg>';

// Steps for the guided tour (see tour.js). target: null renders as a
// centered card instead of spotlighting an element. Device-card steps
// target the Mobile card specifically — all four work identically, so
// walking through one is enough rather than repeating it four times.
// Sentences here are kept short and plain on purpose — this is the very
// first thing a new user reads, so it's not the place for long or clever
// phrasing.
const TOUR_STEPS = [
  {
    target: null,
    title: "Welcome to Sense",
    body: "Sense shows one website at four screen sizes at the same time. No more resizing your browser by hand. Here's a quick look around.",
  },
  {
    target: "#url-input",
    title: "Enter a URL",
    body: "Type or paste a website address here. Click the box any time to see your last 8 links.",
  },
  {
    target: ".url-form .btn-primary",
    title: "Load the preview",
    body: "Click View, or just press Enter. The page loads on all four screens at once.",
  },
  {
    target: "#reload-all",
    title: "Reload everything",
    body: "Reloads all four previews at once. Use this after the page you're testing changes.",
  },
  {
    target: "#export-all",
    title: "Save all four screens",
    body: "Saves all four previews together as one image — handy for sharing your work.",
  },
  {
    target: "#theme-toggle",
    title: "Light or dark",
    body: "Switches Sense between light and dark mode. Your choice is remembered for next time.",
  },
  {
    target: ".category-toggles",
    title: "Show or hide sizes",
    body: "Click a pill to hide or show that size. At least one size must always stay visible.",
  },
  {
    target: '.device-card[data-category="mobile"] .device-select',
    title: "Pick a device",
    body: "Each card can show a specific phone, tablet, laptop, or desktop. Changing one card never changes the others.",
  },
  {
    target: '.device-card[data-category="mobile"] .rotate-btn',
    title: "Rotate a card",
    body: "Flips this card between portrait and landscape. The badge next to the size tells you which one you're in. Sense remembers this choice per card.",
  },
  {
    target: '.device-card[data-category="mobile"] .screenshot-btn',
    title: "Save one screenshot",
    body: "Saves just this card's preview as an image. If the card is off-screen, Sense scrolls to it first.",
  },
  {
    target: null,
    title: "You're all set",
    body: "Open this tour again anytime from the (?) icon in the toolbar. The gear icon next to it opens Settings, where you can add or remove devices.",
  },
];

function showError(message) {
  urlError.textContent = message || "";
  urlError.hidden = !message;
}

// Shared by both places that (re)navigate every frame at once — a plain
// wrapper so the variant/duration pairing can't drift between the two call
// sites (see main() below).
function showLoadingToast(message) {
  return showToast(message, { variant: "loading", duration: null });
}

// One category pill: category.name/icon on the left, a checkmark that
// swaps in when active. Self-contained (no closure over main()'s state) so
// it can be unit-tested or reused independent of how main() calls it.
function createCategoryToggle(category, isVisible, onToggle) {
  const button = document.createElement("button");
  button.type = "button";
  button.className = "category-toggle";

  const icon = document.createElement("span");
  icon.className = "category-toggle-icon";
  icon.setAttribute("aria-hidden", "true");

  const categoryIcon = CATEGORY_ICONS[category.id] ?? CHECK_ICON;
  icon.innerHTML = isVisible ? CHECK_ICON : categoryIcon;

  const label = document.createElement("span");
  label.className = "category-toggle-label";
  label.textContent = category.name;

  button.append(icon, label);
  button.setAttribute("aria-pressed", String(isVisible));

  button.addEventListener("click", () => {
    const nowVisible = onToggle();
    if (nowVisible === undefined) return; // toggle was refused (last visible category)
    button.setAttribute("aria-pressed", String(nowVisible));
    icon.innerHTML = nowVisible ? CHECK_ICON : categoryIcon;
  });

  return button;
}

async function main() {
  await applyStoredTheme();
  initThemeToggle(themeToggleBtn, { lightIcon: SUN_ICON, darkIcon: MOON_ICON });

  let recentUrls = [];

  // Splits a URL into its hostname (always shown in full, bold) and the
  // rest (path/query, muted, truncated) — makes the list scannable by site
  // at a glance instead of reading each full string left to right.
  function splitUrlForDisplay(url) {
    try {
      const parsed = new URL(url);
      const rest = parsed.pathname === "/" ? "" : parsed.pathname + parsed.search;
      return { host: parsed.hostname, rest };
    } catch {
      return { host: url, rest: "" };
    }
  }

  function renderRecentUrls(urls) {
    recentUrls = urls;
    recentUrlsMenu.innerHTML = "";
    for (const url of urls) {
      const { host, rest } = splitUrlForDisplay(url);

      const item = document.createElement("li");
      const button = document.createElement("button");
      button.type = "button";

      const icon = document.createElement("span");
      icon.className = "recent-url-icon";
      icon.setAttribute("aria-hidden", "true");
      icon.innerHTML = HISTORY_ICON;

      const text = document.createElement("span");
      text.className = "recent-url-text";

      const domain = document.createElement("span");
      domain.className = "recent-url-domain";
      domain.textContent = host;

      const path = document.createElement("span");
      path.className = "recent-url-path";
      path.textContent = rest;

      text.append(domain, path);

      const goIcon = document.createElement("span");
      goIcon.className = "recent-url-go";
      goIcon.setAttribute("aria-hidden", "true");
      goIcon.innerHTML = GO_ICON;

      button.append(icon, text, goIcon);
      button.addEventListener("click", () => {
        hideRecentUrls();
        setUrl(url);
      });

      // Simple linear focus navigation between menu items, entered from the
      // URL input via ArrowDown below — keeps the list comfortable to use
      // from the keyboard, not just the mouse.
      button.addEventListener("keydown", (event) => {
        if (event.key === "Escape") {
          // Order matters: focusing the input fires its own "focus" listener
          // (showRecentUrls), which would re-open the menu if this ran second.
          urlInput.focus();
          hideRecentUrls();
        } else if (event.key === "ArrowDown") {
          event.preventDefault();
          const next = item.nextElementSibling?.querySelector("button");
          next?.focus();
        } else if (event.key === "ArrowUp") {
          event.preventDefault();
          const prev = item.previousElementSibling?.querySelector("button");
          if (prev) prev.focus();
          else urlInput.focus();
        }
      });

      item.appendChild(button);
      recentUrlsMenu.appendChild(item);
    }
  }

  function showRecentUrls() {
    if (recentUrls.length > 0) recentUrlsMenu.hidden = false;
  }

  function hideRecentUrls() {
    recentUrlsMenu.hidden = true;
  }

  renderRecentUrls(await getRecentUrls());

  const storedCatalog = await getDeviceCatalog();
  const categories = storedCatalog && storedCatalog.length ? storedCatalog : DEFAULT_DEVICE_CATEGORIES;

  const viewBtn = urlForm.querySelector('button[type="submit"]');

  // Reloading, submitting a new URL, or toggling a category's visibility all
  // eventually call relayout() — if any of that fires while a screenshot is
  // mid-capture (which depends on a card's size/scale staying put while it
  // scrolls the page), the capture would end up reading a moving target.
  function setToolbarBusy(isBusy) {
    reloadBtn.disabled = isBusy || !currentUrl;
    exportAllBtn.disabled = isBusy || !currentUrl;
    urlInput.disabled = isBusy;
    viewBtn.disabled = isBusy;
    for (const toggle of categoryTogglesEl.querySelectorAll(".category-toggle")) {
      toggle.disabled = isBusy;
    }
  }

  const grid = new DeviceGrid(gridEl, categories, {
    onDeviceChange: async (categoryId, deviceId) => {
      const selection = await getDeviceSelection();
      selection[categoryId] = { ...selection[categoryId], deviceId };
      setDeviceSelection(selection);
    },
    onOrientationChange: async (categoryId, orientation) => {
      const selection = await getDeviceSelection();
      selection[categoryId] = { ...selection[categoryId], orientation };
      setDeviceSelection(selection);
    },
    onBusyChange: setToolbarBusy,
  });

  const storedSelection = await getDeviceSelection();
  for (const [categoryId, saved] of Object.entries(storedSelection)) {
    if (saved.deviceId) grid.selectDevice(categoryId, saved.deviceId);
    if (saved.orientation) grid.selectOrientation(categoryId, saved.orientation);
  }

  const storedVisible = await getVisibleCategories();
  let visibleIds = new Set(storedVisible ?? categories.map((c) => c.id));
  grid.setVisibleCategories(storedVisible);

  categoryTogglesEl.innerHTML = "";
  for (const category of categories) {
    const toggleBtn = createCategoryToggle(category, visibleIds.has(category.id), () => {
      const next = new Set(visibleIds);
      if (next.has(category.id)) {
        if (next.size === 1) return undefined; // keep at least one category visible
        next.delete(category.id);
      } else {
        next.add(category.id);
      }
      visibleIds = next;

      const idsArray = categories.map((c) => c.id).filter((id) => next.has(id));
      grid.setVisibleCategories(idsArray);
      setVisibleCategories(idsArray);

      return next.has(category.id);
    });
    categoryTogglesEl.appendChild(toggleBtn);
  }

  let currentUrl = "";

  function setUrl(url) {
    currentUrl = url || "";

    const next = new URL(location.href);
    if (currentUrl) {
      next.searchParams.set("url", currentUrl);
    } else {
      next.searchParams.delete("url");
    }
    history.replaceState(null, "", next.toString());

    urlInput.value = currentUrl;
    gridEl.hidden = !currentUrl;
    emptyStateEl.hidden = !!currentUrl;
    reloadBtn.disabled = !currentUrl;
    exportAllBtn.disabled = !currentUrl;

    if (currentUrl) {
      const dismissLoading = showLoadingToast("Loading previews…");
      grid.load(currentUrl).then(dismissLoading);
      setLastUrl(currentUrl);
      addRecentUrl(currentUrl).then(renderRecentUrls);
    }
  }

  urlForm.addEventListener("submit", (event) => {
    event.preventDefault();
    const normalized = normalizeUrl(urlInput.value);

    if (!normalized) {
      showError("Enter a valid URL, e.g. https://example.com");
      return;
    }

    showError("");
    hideRecentUrls();
    setUrl(normalized);
  });

  urlInput.addEventListener("focus", showRecentUrls);

  // Delayed, and checks where focus actually landed, so moving focus INTO
  // the menu — via a mouse click or via ArrowDown below — doesn't get
  // closed out from under the user by this same blur handler.
  urlInput.addEventListener("blur", () => {
    setTimeout(() => {
      if (!recentUrlsMenu.contains(document.activeElement)) hideRecentUrls();
    }, 150);
  });

  urlInput.addEventListener("keydown", (event) => {
    if (event.key === "Escape") {
      hideRecentUrls();
    } else if (event.key === "ArrowDown" && !recentUrlsMenu.hidden) {
      event.preventDefault();
      recentUrlsMenu.querySelector("button")?.focus();
    }
  });

  reloadBtn.addEventListener("click", () => {
    const dismissLoading = showLoadingToast("Reloading previews…");
    grid.reload().then(dismissLoading);
  });

  exportAllBtn.addEventListener("click", async () => {
    grid.setBusy(true);
    exportAllBtn.classList.add("is-busy");
    exportAllBtn.innerHTML = SPINNER_ICON;
    try {
      await captureAllCards(grid.entries, {
        onCardStart: (entry) => grid.setCardCapturing(entry, true),
        onCardEnd: (entry) => grid.setCardCapturing(entry, false),
      });
      showToast("Saved combined screenshot", { variant: "success" });
    } catch (error) {
      console.warn("Sense: couldn't export the combined screenshot.", error);
      showToast("Couldn't save the combined screenshot — try again.", { variant: "error" });
    } finally {
      exportAllBtn.classList.remove("is-busy");
      exportAllBtn.innerHTML = EXPORT_ICON;
      grid.setBusy(false);
    }
  });

  let resizeTimer;
  window.addEventListener("resize", () => {
    clearTimeout(resizeTimer);
    resizeTimer = setTimeout(() => {
      if (currentUrl) grid.relayout();
    }, 120);
  });

  const initialParams = new URLSearchParams(location.search);
  const rawInitialUrl = initialParams.get("url");
  const normalizedInitialUrl = normalizeUrl(rawInitialUrl);

  if (normalizedInitialUrl) {
    setUrl(normalizedInitialUrl);
  } else if (rawInitialUrl) {
    showError("That page's address couldn't be previewed. Enter a URL manually.");
  } else {
    const lastUrl = await getLastUrl();
    if (lastUrl) setUrl(lastUrl);
  }

  urlInput.focus();

  // A few tour steps target controls inside the device grid, which stays
  // hidden until a URL is loaded — reveal it for the tour's duration if
  // needed, and only re-hide it afterward if the user still hasn't entered
  // one by the time the tour ends.
  function runTour() {
    const gridWasHidden = gridEl.hidden;
    if (gridWasHidden) {
      gridEl.hidden = false;
      emptyStateEl.hidden = true;
      grid.relayout();
    }

    new Tour(TOUR_STEPS, {
      onFinish: () => {
        setTourCompleted(true);
        if (gridWasHidden && !currentUrl) {
          gridEl.hidden = true;
          emptyStateEl.hidden = false;
        }
      },
    }).start();
  }

  tourHelpBtn.addEventListener("click", runTour);
  openSettingsBtn.addEventListener("click", () => {
    // chrome.runtime goes undefined if this tab was opened before the
    // extension was last reloaded/updated — its connection is invalidated,
    // not just this one call. Surfacing that beats a silent dead click.
    try {
      chrome.runtime.openOptionsPage();
    } catch (error) {
      console.warn("Sense: couldn't open settings.", error);
      showToast("Couldn't open settings — close and reopen this tab, then try again.", { variant: "error" });
    }
  });

  if (!(await getTourCompleted())) {
    runTour();
  }
}

main();
